let textbox = <HTMLElement>document.querySelector('#text-input');
let results = <HTMLElement>document.querySelector('#results');
