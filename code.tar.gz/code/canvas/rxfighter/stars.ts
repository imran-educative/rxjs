import { Observable } from 'rxjs';
import { GameState } from './gameState';
import { config } from './config';
import { randInt } from './util';
import { ctx } from './index';
import { map } from 'rxjs/operators';

