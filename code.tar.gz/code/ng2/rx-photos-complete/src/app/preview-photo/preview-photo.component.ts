import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preview-photo',
  templateUrl: './preview-photo.component.html',
  styleUrls: ['./preview-photo.component.css']
})
export class PreviewPhotoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
